import { spawn } from 'node:child_process';

const node = process.execPath;
const backend = spawn(node, ['server/index.js'], { stdio: 'inherit', env: process.env });
const frontend = spawn(node, ['node_modules/vite/bin/vite.js', '--configLoader', 'runner', '--host', '0.0.0.0', ...process.argv.slice(2)], { stdio: 'inherit', env: process.env });
let stopping = false;
const stop = (child, signal = 'SIGTERM') => { if (child && child.exitCode === null && !child.killed) child.kill(signal); };
const shutdown = signal => {
  if (stopping) return;
  stopping = true; stop(backend, signal); stop(frontend, signal);
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
frontend.on('error', error => { console.error('Vite gagal dijalankan:', error.message); shutdown(); process.exitCode = 1; });
backend.on('error', error => console.error('Backend global gagal dijalankan:', error.message));
backend.on('exit', code => { if (!stopping && code && frontend.exitCode === null) console.error(`Backend berhenti dengan kode ${code}; frontend tetap berjalan.`); });
frontend.on('exit', code => { if (!stopping) { stopping = true; stop(backend); process.exitCode = code ?? 0; } });
