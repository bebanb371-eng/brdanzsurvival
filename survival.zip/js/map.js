import{loadGame}from'../src/store.js';
const canvas=document.querySelector('#island-map'),ctx=canvas.getContext('2d'),label=document.querySelector('#map-coordinates');let zoom=1;
function draw(){const box=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);canvas.width=box.width*dpr;canvas.height=box.height*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);const w=box.width,h=box.height,cx=w/2,cy=h/2,scale=Math.min(w,h)/180*zoom;ctx.fillStyle='#102c3a';ctx.fillRect(0,0,w,h);
 // island shape and height tinted forest regions
 ctx.save();ctx.translate(cx,cy);ctx.scale(scale,scale);ctx.beginPath();for(let i=0;i<=180;i++){const a=i/180*Math.PI*2,r=72+Math.sin(a*3+1)*6+Math.cos(a*7)*4,x=Math.cos(a)*r,z=Math.sin(a)*r;i?ctx.lineTo(x,z):ctx.moveTo(x,z)}ctx.closePath();ctx.fillStyle='#687c47';ctx.fill();ctx.strokeStyle='#bac586';ctx.lineWidth=1.2/scale;ctx.stroke();
 for(let i=0;i<20;i++){const x=Math.sin(i*48.13)*46,z=Math.cos(i*37.7)*48;ctx.beginPath();ctx.ellipse(x,z,5+Math.sin(i)*2,3+Math.cos(i)*2,i,0,Math.PI*2);ctx.fillStyle=i%4===0?'#718454':'#526f46';ctx.fill()}
 // winding track
 ctx.beginPath();ctx.moveTo(-2,65);for(let z=65;z>-61;z-=2)ctx.lineTo(Math.sin((65-z)*.025)*8,z);ctx.strokeStyle='#b9a174';ctx.lineWidth=2.2/scale;ctx.stroke();
 // lake and landmark dots
 ctx.beginPath();ctx.ellipse(24,-20,12,8,-.4,0,Math.PI*2);ctx.fillStyle='#367b8a';ctx.fill();ctx.fillStyle='#f2bd22';ctx.fillRect(-4,-29,4,4);ctx.fillStyle='#f2bd22';ctx.beginPath();ctx.arc(-10,-20,2.2,0,Math.PI*2);ctx.fill();
 const s=loadGame(),p=s.world.position;ctx.save();ctx.translate(p.x,-p.z);ctx.rotate(-s.world.yaw||0);ctx.fillStyle='#39c6ff';ctx.strokeStyle='#e7fbff';ctx.lineWidth=1/scale;ctx.beginPath();ctx.moveTo(0,-4);ctx.lineTo(2.6,3);ctx.lineTo(0,2);ctx.lineTo(-2.6,3);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();ctx.restore();label.textContent=`${p.x.toFixed(1)}, ${p.z.toFixed(1)}`;
}
document.querySelector('#zoom-in').onclick=()=>{zoom=Math.min(2.2,zoom+.2);draw()};document.querySelector('#zoom-out').onclick=()=>{zoom=Math.max(.7,zoom-.2);draw()};addEventListener('resize',draw);draw();setInterval(draw,1000);
