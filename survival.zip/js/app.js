import { loadGame, saveGame, craft } from '../src/store.js';
import { createScene } from '../src/scene.js';
import { connectSocket } from '../src/net.js';
import * as THREE from 'three';
import loadingVideoUrl from '../assets/video/brdanz-loading.mp4?url';

const page = document.body.dataset.page;
const state = loadGame();
const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];

function persist() { saveGame(state); renderStats(); }
function renderStats() {
  const player = state.player;
  $$('[data-player]').forEach(element => element.textContent = player[element.dataset.player]);
  $$('[data-coins]').forEach(element => element.textContent = player.coins);
  $$('[data-gems]').forEach(element => element.textContent = player.gems);
  $$('[data-item]').forEach(element => element.textContent = state.inventory[element.dataset.item] || 0);
  $$('[data-ammo]').forEach(element => element.textContent = state.inventory[{ rifle: 'ammo', pistol: 'pistolAmmo', sniper: 'sniperAmmo' }[element.dataset.ammo]] ?? '∞');
  $$('[data-stat]').forEach(element => { element.style.width = `${state.player[element.dataset.stat] || 0}%`; });
}
renderStats();

const canvas = $('#world');
if (canvas) {
  const world = createScene(canvas, { interactive: page === 'survival', openDoors: state.world.openDoors, takenLoot: state.world.takenLoot, defeatedThreats: state.world.defeatedThreats, minedNodes: state.world.minedNodes, skin: state.skin, mode: page, quality: state.settings.quality, timeOfDay: state.world.timeOfDay, weather: state.world.weather, houses: state.world.houses });
  if (page === 'skins' || page === 'character') {
    let dragX = null;
    canvas.addEventListener('pointerdown', event => { dragX = event.clientX; canvas.setPointerCapture(event.pointerId); });
    canvas.addEventListener('pointermove', event => {
      if (dragX === null) return;
      world.rotatePreview((event.clientX - dragX) * .012); dragX = event.clientX;
    });
    canvas.addEventListener('pointerup', () => { dragX = null; });
    canvas.addEventListener('pointercancel', () => { dragX = null; });
    canvas.addEventListener('wheel', event => { event.preventDefault(); world.rotatePreview(event.deltaY * .0015); }, { passive: false });
  }
  window.addEventListener('beforeunload', () => world.dispose(), { once: true });
}

$$('[data-action="back"]').forEach(button => button.onclick = () => location.href = button.dataset.to || 'lobby.html');
$$('[data-save]').forEach(button => button.onclick = () => { persist(); button.textContent = 'Tersimpan ✓'; setTimeout(() => button.textContent = 'Simpan', 1200); });
$$('[data-craft]').forEach(button => button.onclick = () => {
  const success = craft(state, button.dataset.craft); persist();
  const message = $('#notice'); if (message) message.textContent = success ? `${button.dataset.craft} berhasil dibuat.` : 'Material belum cukup.';
});
$$('[data-buy]').forEach(button => button.onclick = () => {
  const cost = +button.dataset.cost, item = button.dataset.buy, amount = +(button.dataset.amount || 1);
  if (state.player.coins < cost) { alert('Koin tidak cukup.'); return; }
  state.player.coins -= cost; state.inventory[item] = (state.inventory[item] || 0) + amount; persist(); button.textContent = 'Dibeli ✓';
});
$$('[data-use]').forEach(button => button.onclick = () => {
  const item = button.dataset.use; if (!state.inventory[item]) return;
  state.inventory[item]--;
  if (item === 'medkit') state.player.hp = Math.min(100, state.player.hp + 35);
  if (item === 'water') state.player.thirst = Math.min(100, state.player.thirst + 40);
  if (item === 'food') state.player.hunger = Math.min(100, state.player.hunger + 35);
  persist();
});
$$('[data-select-skin]').forEach(button => button.onclick = () => {
  const skin = button.dataset.selectSkin; if (!state.unlockedSkins.includes(skin)) return;
  state.skin = skin; persist(); canvas?.__world?.setSkin(skin); canvas?.__world?.equipWeapon(state.selectedWeapon || 'rifle');
  $$('[data-select-skin]').forEach(item => item.closest('[data-skin-card]')?.classList.toggle('selected', item.dataset.selectSkin === skin));
  const name = $('#selected-skin'); if (name) name.textContent = skin;
});
function refreshSkinCards() {
  $$('[data-skin-card]').forEach(card => {
    const name = card.dataset.skinCard, unlocked = state.unlockedSkins.includes(name);
    card.classList.toggle('selected', state.skin === name);
    card.querySelector('[data-select-skin]')?.toggleAttribute('hidden', !unlocked);
    const purchase = card.querySelector('[data-unlock-skin]'); if (purchase) purchase.hidden = unlocked;
  });
  const name = $('#selected-skin'); if (name) name.textContent = state.skin;
}
$$('[data-unlock-skin]').forEach(button => button.addEventListener('click', () => {
  const skin = button.dataset.unlockSkin, cost = +button.dataset.cost;
  if (state.unlockedSkins.includes(skin)) return;
  if (state.player.coins < cost) { const message = $('#skin-notice'); if (message) message.textContent = `Koin kurang. Butuh ${cost.toLocaleString('id-ID')} koin.`; return; }
  state.player.coins -= cost; state.unlockedSkins.push(skin); state.skin = skin; persist();
  canvas?.__world?.setSkin(skin); canvas?.__world?.equipWeapon(state.selectedWeapon || 'rifle'); refreshSkinCards();
  const message = $('#skin-notice'); if (message) message.textContent = `${skin} berhasil dibuka dan dipakai.`;
}));
refreshSkinCards();
$$('[data-setting]').forEach(element => {
  element.value = state.settings[element.dataset.setting] ?? element.value;
  element.onchange = () => { state.settings[element.dataset.setting] = element.value; persist(); };
});
const bindingNames = { forward:'Maju', backward:'Mundur', left:'Kiri', right:'Kanan', run:'Lari', jump:'Lompat', interact:'Interaksi', mine:'Tambang', camera:'Kamera', pause:'Jeda' };
const keyLabel = key => ({ space:'SPACE', escape:'ESC', shift:'SHIFT', arrowup:'↑', arrowdown:'↓', arrowleft:'←', arrowright:'→' }[key] || key.toUpperCase());
const refreshBindingLabels = () => $$('[data-bind-key]').forEach(button => { const action = button.dataset.bindKey; button.textContent = `${bindingNames[action]} · ${keyLabel(state.settings.keyBindings[action])}`; });
refreshBindingLabels();
$$('[data-bind-key]').forEach(button => button.addEventListener('click', () => {
  const action = button.dataset.bindKey; button.textContent = `${bindingNames[action]} · tekan tombol…`;
  const capture = event => {
    event.preventDefault(); event.stopPropagation();
    const key = event.key.toLowerCase() === ' ' ? 'space' : event.key.toLowerCase();
    if (!/^(?:[a-z0-9]|space|shift|escape|arrowup|arrowdown|arrowleft|arrowright)$/.test(key)) return;
    state.settings.keyBindings[action] = key; window.removeEventListener('keydown', capture, true); refreshBindingLabels(); persist();
  };
  window.addEventListener('keydown', capture, true);
}));
$('#reset-bindings')?.addEventListener('click', () => {
  state.settings.keyBindings = { forward:'w', backward:'s', left:'a', right:'d', run:'shift', jump:'space', interact:'e', mine:'f', camera:'q', pause:'escape' };
  refreshBindingLabels(); persist();
});
const editControls = $('#edit-controls');
if (editControls) {
  const controls = [...document.querySelectorAll('#joystick, .touch-actions [data-layout-control]')];
  controls.forEach(control => {
    const id = control.dataset.layoutControl || (control.dataset.layoutControl = 'joystick'), saved = state.settings.controlLayout[id];
    if (saved) { control.style.position = 'fixed'; control.style.left = `${Math.max(0, Math.min(innerWidth - control.offsetWidth, saved.x * innerWidth - control.offsetWidth / 2))}px`; control.style.top = `${Math.max(0, Math.min(innerHeight - control.offsetHeight, saved.y * innerHeight - control.offsetHeight / 2))}px`; control.style.right = 'auto'; control.style.bottom = 'auto'; control.style.zIndex = '5'; }
  });
  if (Object.keys(state.settings.controlLayout).length) document.body.classList.add('has-control-layout');
  let editing = false;
  const closeEditor = () => { editing = false; document.body.classList.remove('controls-editing'); if (Object.keys(state.settings.controlLayout).length) document.body.classList.add('has-control-layout'); editControls.textContent = 'Atur tombol'; persist(); };
  const openEditor = () => {
    editing = true; document.body.classList.add('controls-editing'); editControls.textContent = 'Simpan layout';
    controls.forEach(control => {
      const id = control.dataset.layoutControl || 'joystick'; control.dataset.layoutControl = id;
      control.style.position = 'fixed'; control.style.right = 'auto'; control.style.bottom = 'auto'; control.style.zIndex = '20';
      const saved = state.settings.controlLayout[id], rect = control.getBoundingClientRect();
      control.style.left = `${Math.max(0, Math.min(innerWidth - rect.width, (saved?.x ?? (rect.left + rect.width / 2) / innerWidth) * innerWidth - rect.width / 2))}px`;
      control.style.top = `${Math.max(0, Math.min(innerHeight - rect.height, (saved?.y ?? (rect.top + rect.height / 2) / innerHeight) * innerHeight - rect.height / 2))}px`;
      state.settings.controlLayout[id] = { x:(parseFloat(control.style.left) + control.offsetWidth / 2) / innerWidth, y:(parseFloat(control.style.top) + control.offsetHeight / 2) / innerHeight };
      control.onpointerdown = event => {
        if (!editing) return; event.preventDefault(); event.stopPropagation(); control.setPointerCapture(event.pointerId);
        const move = pointer => { const x = Math.max(0, Math.min(innerWidth - control.offsetWidth, pointer.clientX - control.offsetWidth / 2)); const y = Math.max(0, Math.min(innerHeight - control.offsetHeight, pointer.clientY - control.offsetHeight / 2)); control.style.left = `${x}px`; control.style.top = `${y}px`; };
        const done = pointer => { move(pointer); state.settings.controlLayout[id] = { x: (parseFloat(control.style.left) + control.offsetWidth / 2) / innerWidth, y: (parseFloat(control.style.top) + control.offsetHeight / 2) / innerHeight }; control.removeEventListener('pointermove', move); control.removeEventListener('pointerup', done); control.removeEventListener('pointercancel', done); persist(); };
        control.addEventListener('pointermove', move); control.addEventListener('pointerup', done); control.addEventListener('pointercancel', done);
      };
    });
  };
  editControls.onclick = () => editing ? closeEditor() : openEditor();
  if (new URLSearchParams(location.search).has('editControls')) openEditor();
}
$$('[data-start]').forEach(button => button.onclick = () => { sessionStorage.setItem('brdanz-loading-dest', 'survival.html'); location.href = 'loading.html'; });
$$('[data-continue]').forEach(button => button.onclick = () => location.href = 'survival.html');
$$('[data-retry]').forEach(button => button.onclick = () => {
  state.player.hp = 100; state.player.hunger = 100; state.player.thirst = 100; persist(); location.href = 'loading.html';
});
$$('[data-loot]').forEach(button => button.onclick = () => {
  const kind = button.dataset.loot, amount = +button.dataset.amount;
  state.inventory[kind] = (state.inventory[kind] || 0) + amount;
  state.missions.wood += kind === 'wood' ? amount : 0; persist(); button.textContent = 'Loot diambil ✓'; button.disabled = true;
});

if (page === 'loading') {
  const video = $('#loading-video');
  if (video) { video.src = loadingVideoUrl; video.play().catch(() => {}); }
  let progress = 0; const bar = $('#load-progress'), label = $('#load-label');
  const timer = setInterval(() => {
    progress = Math.min(100, progress + Math.ceil(Math.random() * 13));
    if (bar) bar.style.width = `${progress}%`; if (label) label.textContent = `${progress}%`;
    if (progress >= 100) { clearInterval(timer); setTimeout(() => location.replace(sessionStorage.getItem('brdanz-loading-dest') || 'survival.html'), 350); }
  }, 180);
}

if (page === 'survival') {
  const world = $('#world')?.__world;
  if (!world) throw new Error('Scene survival gagal dibuat.');
  const keys = new Set(), joystick = { x: 0, y: 0, pointer: null }, look = { down: false, x: 0, y: 0 };
  const bindings = state.settings.keyBindings;
  const bound = action => keys.has(bindings[action]);
  let yaw = Number.isFinite(state.world.yaw) ? state.world.yaw : 0;
  let pitch = .17, verticalSpeed = 0, grounded = true, stamina = state.player.stamina;
  let previousTime = performance.now(), survivalTimer = 0, attackTimer = 0, damageCooldown = 0, network = null, networkReady = false;
  let fireTimer = 0, mapTimer = 0, noticeTimer = 0, movementClock = 0;
  let environmentTimer = 0, weatherTimer = 0;
  const weatherNames = { clear:'Cerah', cloudy:'Mendung', rain:'Hujan' };
  const weatherLabel = $('#weather-status'); if (weatherLabel) { weatherLabel.textContent = weatherNames[world.weather] || 'Cerah'; weatherLabel.dataset.weather = world.weather; }
  const walkingSpeed = 4.2, runningSpeed = 7.1, bodyRadius = .36;
  const weapons = {
    rifle: { ammo: 'ammo', damage: 29, range: 52, cooldown: .32, cone: .64 },
    pistol: { ammo: 'pistolAmmo', damage: 38, range: 29, cooldown: .43, cone: .58 },
    sniper: { ammo: 'sniperAmmo', damage: 92, range: 95, cooldown: 1.05, cone: .84 },
    knife: { ammo: null, damage: 42, range: 2.2, cooldown: .55, cone: .15 },
    pickaxe: { ammo: null, damage: 26, range: 3.2, cooldown: .48, cone: .2 }
  };
  let selectedWeapon = ['rifle', 'pistol', 'sniper', 'knife', 'pickaxe'].includes(state.selectedWeapon) ? state.selectedWeapon : 'rifle';
  const cameraModes = ['first', 'shoulder', 'third'];
  const cameraNames = { first:'Orang pertama', shoulder:'Over-shoulder', third:'Orang ketiga' };
  let cameraMode = state.settings.cameraMode;
  world.setFirstPerson(cameraMode === 'first');
  const refreshCameraButton = () => { const button = $('#mobile-camera'); if (button) button.title = `Kamera: ${cameraNames[cameraMode]} · Q untuk ganti`; };
  const setCameraMode = mode => { cameraMode = mode; state.settings.cameraMode = mode; world.setFirstPerson(mode === 'first'); refreshCameraButton(); persist(); notice(`Kamera · ${cameraNames[mode]}`); };
  const cycleCamera = () => setCameraMode(cameraModes[(cameraModes.indexOf(cameraMode) + 1) % cameraModes.length]);
  refreshCameraButton();
  if ($('#mobile-use')) $('#mobile-use').textContent = keyLabel(bindings.interact);
  if ($('#mobile-mine')) $('#mobile-mine').title = `Tambang · ${keyLabel(bindings.mine)}`;
  world.equipWeapon(selectedWeapon);
  const selectedButtons = $$('[data-weapon]');
  const updateWeaponButtons = () => selectedButtons.forEach(button => button.classList.toggle('active', button.dataset.weapon === selectedWeapon));
  const notice = (text, duration = 2600) => {
    const element = $('#notice'); if (!element) return;
    element.textContent = text; element.classList.add('show'); clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => element.classList.remove('show'), duration);
  };
  const sleepAtHome = () => {
    const owned = [['guardian', 0, -20], ['forest', -37, 18], ['hill', 68, 50]].filter(([id]) => state.world.houses[id]?.owned);
    const home = owned.find(([, x, z]) => distance(x, z) < 6);
    if (!home) { notice('Tidur hanya bisa di dekat rumah milikmu.'); return; }
    if (state.world.timeOfDay >= 6 && state.world.timeOfDay < 19) { notice('Hari masih terang. Kamu bisa tidur setelah malam tiba.'); return; }
    state.world.timeOfDay = 7; state.world.day++; state.player.hp = Math.min(100, state.player.hp + 35); state.player.hunger = Math.max(0, state.player.hunger - 5); state.player.thirst = Math.max(0, state.player.thirst - 7);
    world.playAction('sleep'); world.setTimeOfDay(state.world.timeOfDay); persist(); notice(`Kamu beristirahat di ${home[0]} sampai pagi.`);
  };
  $('#sleep-button')?.addEventListener('click', sleepAtHome);
  const setWeapon = kind => {
    if (!weapons[kind]) return;
    selectedWeapon = kind; state.selectedWeapon = kind; world.equipWeapon(kind); updateWeaponButtons(); persist();
  };
  selectedButtons.forEach(button => button.addEventListener('click', () => setWeapon(button.dataset.weapon)));
  updateWeaponButtons();

  const playerPosition = () => state.world.position;
  const distance = (x, z) => Math.hypot(x - playerPosition().x, z - playerPosition().z);
  const nearestLoot = () => world.loot.filter(item => !item.taken).sort((a, b) => distance(a.x, a.z) - distance(b.x, b.z))[0];
  const nearestInteractable = () => world.interactables.filter(item => !item.dead).sort((a, b) => distance(a.x, a.z) - distance(b.x, b.z))[0];
  const liveThreats = () => [...world.enemies, ...world.animals].filter(entity => entity.alive);
  const nearestThreat = () => liveThreats().sort((a, b) => distance(a.x, a.z) - distance(b.x, b.z))[0];
  const nearestMineable = () => world.mineables.filter(node => node && world.scene.getObjectById(node.group.id)).sort((a, b) => distance(a.x, a.z) - distance(b.x, b.z))[0];
  const nearestAction = () => {
    const loot = nearestLoot(), object = nearestInteractable(), threat = nearestThreat(), node = nearestMineable();
    const candidates = [];
    if (loot && distance(loot.x, loot.z) < 2.65) candidates.push({ type: 'loot', entity: loot, range: distance(loot.x, loot.z), label: `Ambil ${loot.kind}` });
    if (object && distance(object.x, object.z) < object.radius) candidates.push({ type: object.type, entity: object, range: distance(object.x, object.z), label: object.type === 'merchant' ? 'Bicara dengan Nara' : object.type === 'npc' ? `Bicara dengan ${object.name.split(' · ')[0]}` : `${object.open ? 'Tutup' : 'Buka'} ${object.name}` });
    if (threat && distance(threat.x, threat.z) < 2.1) candidates.push({ type: 'melee', entity: threat, range: distance(threat.x, threat.z), label: `Serang ${threat.name}` });
    if (node && distance(node.x, node.z) < 3.3) candidates.push({ type: 'mine', entity: node, range: distance(node.x, node.z), label: `Tambang ${node.resource}` });
    return candidates.sort((a, b) => a.range - b.range)[0] || null;
  };

  function mineNearest() {
    const node = nearestMineable();
    if (!node || distance(node.x, node.z) > 3.3) { notice('Dekati bongkahan bijih dan tekan F untuk menambang.'); return; }
    if (!world.removeMineable(node)) return;
    if (!state.world.minedNodes.includes(node.id)) state.world.minedNodes.push(node.id);
    state.inventory[node.resource] = (state.inventory[node.resource] || 0) + node.amount;
    state.player.xp += 8; world.playAction('mine'); persist();
    notice(`Bijih ${node.resource} ditambang · +${node.amount} ${node.resource} · +8 XP`);
  }

  function takeLoot(item) {
    if (item.taken) return;
    item.taken = true; world.scene.remove(item.group);
    if (item.id && !state.world.takenLoot.includes(item.id)) state.world.takenLoot.push(item.id);
    const amount = item.kind === 'ammo' ? 12 : 1;
    const inventoryKey = item.kind === 'ammo' ? 'ammo' : item.kind;
    state.inventory[inventoryKey] = (state.inventory[inventoryKey] || 0) + amount;
    if (item.kind === 'wood') state.missions.wood++;
    state.player.xp += 5; world.playAction('pickup'); persist();
    notice(`Barang diambil: +${amount} ${inventoryKey} · +5 XP`);
  }

  const hurtPlayer = (amount, source) => {
    if (damageCooldown > 0) return;
    damageCooldown = .78; state.player.hp = Math.max(0, state.player.hp - amount); persist();
    world.playAction('hurt');
    const flash = $('#damage-flash'); flash?.classList.add('active'); setTimeout(() => flash?.classList.remove('active'), 190);
    notice(`${source} menyerang! −${amount} HP`, 1900);
    if (state.player.hp <= 0) { saveGame(state); location.href = 'gameover.html'; }
  };

  function applyHit(target, damage) {
    if (!target?.alive) return;
    target.health = Math.max(0, target.health - damage);
    world.updateHealth(target);
    target.moving = false;
    if (target.health <= 0) {
      target.alive = false; target.corpseAt = performance.now(); target.fallSide = Math.random() < .5 ? -1 : 1; target.fallFrom = target.group.rotation.z;
      target.attackingUntil = 0; target.group.visible = true;
      if (target.id && !state.world.defeatedThreats.includes(target.id)) state.world.defeatedThreats.push(target.id);
      const reward = target.type === 'wolf' ? 22 : 50;
      state.player.kills++; state.player.xp += target.type === 'wolf' ? 24 : 32; state.player.coins += reward;
      notice(`${target.name} tumbang · +${reward} koin`);
      addDroppedLoot(target.x, target.z, target.type === 'wolf' ? 'food' : 'ammo');
    } else { target.hitAt = performance.now(); target.group.rotation.x = -.08; notice(`${target.name} terkena ${damage} damage · HP ${target.health}`); }
    persist();
  }

  function addDroppedLoot(x, z, kind) {
    const group = new THREE.Group();
    const color = kind === 'food' ? '#bd884c' : '#c6aa43';
    const material = new THREE.MeshStandardMaterial({ color, roughness: .76, emissive: color, emissiveIntensity: .08 });
    const geometry = kind === 'food' ? new THREE.CylinderGeometry(.17, .17, .28, 12) : new THREE.BoxGeometry(.34, .22, .34);
    const drop = new THREE.Mesh(geometry, material); drop.castShadow = true; group.add(drop);
    group.position.set(x, world.heightAt(x, z) + .42, z); world.scene.add(group);
    world.loot.push({ group, kind, taken: false, x, z, baseY: group.position.y, phase: Math.random() * Math.PI * 2 });
  }

  function shoot() {
    if (fireTimer > 0) return;
    if (selectedWeapon === 'pickaxe') { fireTimer = weapons.pickaxe.cooldown; mineNearest(); return; }
    const weapon = weapons[selectedWeapon]; fireTimer = weapon.cooldown;
    if (weapon.ammo && state.inventory[weapon.ammo] < 1) { notice(`${selectedWeapon.toUpperCase()} kehabisan peluru. Cari ammo atau kunjungi toko.`); return; }
    if (weapon.ammo) state.inventory[weapon.ammo]--;
    world.hero.rotation.y = yaw;
    const direction = new THREE.Vector3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch)).normalize();
    const origin = new THREE.Vector3(playerPosition().x, world.hero.position.y + (cameraMode === 'first' ? 1.62 : 1.42), playerPosition().z).addScaledVector(direction, .42);
    const candidates = liveThreats().map(target => {
      const targetPos = new THREE.Vector3(target.x, world.heightAt(target.x, target.z) + (target.type === 'wolf' ? .58 : 1.22), target.z);
      const to = targetPos.clone().sub(origin), along = to.dot(direction), range = to.length(), miss = to.addScaledVector(direction, -along).length();
      return { target, targetPos, along, range, miss };
    });
    for (const [username, remote] of world.remotes) {
      const p = remote.group.position, targetPos = new THREE.Vector3(p.x, p.y + 1.2, p.z), to = targetPos.clone().sub(origin), along = to.dot(direction), range = to.length(), miss = to.addScaledVector(direction, -along).length();
      candidates.push({ target:{type:'player',username}, targetPos, along, range, miss });
    }
    const selected = candidates.filter(item => item.along >= 0 && item.along <= weapon.range && item.range <= weapon.range && item.miss < (item.target.type === 'wolf' ? .62 : item.target.type === 'player' ? .66 : .56)).sort((a, b) => a.along - b.along)[0];
    world.raycaster.set(origin, direction); world.raycaster.far = weapon.range;
    const blockers = world.raycaster.intersectObjects(world.cameraBlockers, false);
    let blockedAt = blockers[0]?.distance ?? weapon.range;
    for (const box of world.colliders) {
      if (box.active === false) continue;
      let near = 0, far = weapon.range, valid = true;
      for (const [at, vector, min, max] of [[origin.x,direction.x,box.x-box.width/2,box.x+box.width/2],[origin.z,direction.z,box.z-box.depth/2,box.z+box.depth/2]]) {
        if (Math.abs(vector) < 1e-6) { if (at < min || at > max) valid = false; continue; }
        let a=(min-at)/vector,b=(max-at)/vector;if(a>b)[a,b]=[b,a];near=Math.max(near,a);far=Math.min(far,b);if(far<near)valid=false;
      }
      const distanceToBox=near>=0?near:far, impactY=origin.y+direction.y*distanceToBox;
      if(valid&&distanceToBox>=0&&distanceToBox<blockedAt&&impactY>=box.y-.12&&impactY<=box.y+box.height)blockedAt=distanceToBox;
    }
    const hit = selected && selected.along <= blockedAt + .16 ? selected.target : null;
    const end = hit ? selected.targetPos.clone() : origin.clone().addScaledVector(direction, Math.min(weapon.range, blockedAt));
    if (selectedWeapon !== 'knife') world.spawnShot(origin, end);
    if (selectedWeapon === 'knife') {
      if (hit?.type === 'player') { if (networkReady) network.send(JSON.stringify({ type:'attack_player', target:hit.username, weapon:selectedWeapon })); }
      else if (hit && selected.range <= weapon.range) applyHit(hit, weapon.damage);
      else notice('Dekati target sebelum menyerang dengan pisau.');
    } else if (hit?.type === 'player') { if (networkReady) network.send(JSON.stringify({ type:'attack_player', target:hit.username, weapon:selectedWeapon })); else notice('Pemain lain terlihat, tetapi server global belum tersambung.'); }
    else if (hit) applyHit(hit, weapon.damage);
    else notice(selected && blockedAt < selected.along ? 'Tembakan terhalang objek.' : 'Tembakan meleset. Arahkan bidikan ke target.');
    world.playAction(selectedWeapon === 'knife' ? 'attack' : 'fire'); persist();
  }

  function interact() {
    const action = nearestAction();
    if (!action) { notice('Tidak ada barang, pintu, atau orang di dekatmu.'); return; }
    if (action.type === 'loot') { takeLoot(action.entity); return; }
    if (action.type === 'mine') { mineNearest(); return; }
    if (action.type === 'merchant') { world.playAction('interact'); notice('Nara: Persediaan baru datang.'); setTimeout(() => location.href = 'shop.html', 450); return; }
    if (action.type === 'npc') { world.playAction('interact'); notice(action.entity.npc.line); return; }
    if (action.type === 'door' || action.type === 'gate') {
      const item = action.entity; item.open = !item.open; item.collider.active = false;
      const openDoors = new Set(state.world.openDoors);
      if (item.open) openDoors.add(item.id); else openDoors.delete(item.id);
      state.world.openDoors = [...openDoors];
      world.playAction('interact'); persist(); notice(`${item.name} ${item.open ? 'dibuka' : 'ditutup'}.`); return;
    }
    if (action.type === 'melee') { applyHit(action.entity, 30); world.playAction('attack'); }
  }

  const consume = kind => {
    if (!state.inventory[kind]) { notice(kind === 'food' ? 'Ransum habis. Cari barang atau beli di toko.' : 'Air bersih habis. Cari barang atau beli di toko.'); return; }
    state.inventory[kind]--;
    if (kind === 'food') { state.player.hunger = Math.min(100, state.player.hunger + 38); notice('Ransum dimakan · lapar berkurang.'); }
    else { state.player.thirst = Math.min(100, state.player.thirst + 48); notice('Air diminum · rasa haus berkurang.'); }
    world.playAction(kind === 'food' ? 'eat' : 'drink'); persist();
  };
  $('#eat-food')?.addEventListener('click', () => consume('food'));
  $('#drink-water')?.addEventListener('click', () => consume('water'));
  $('#mobile-use')?.addEventListener('pointerdown', event => { if (!document.body.classList.contains('controls-editing')) interact(); });
  $('#mobile-mine')?.addEventListener('pointerdown', () => { if (!document.body.classList.contains('controls-editing')) mineNearest(); });
  $('#mobile-camera')?.addEventListener('pointerdown', () => { if (!document.body.classList.contains('controls-editing')) cycleCamera(); });
  $('#mobile-fire')?.addEventListener('pointerdown', () => { if (!document.body.classList.contains('controls-editing')) shoot(); });
  $('#mobile-jump')?.addEventListener('pointerdown', () => { if (!document.body.classList.contains('controls-editing') && grounded) { verticalSpeed = 7.1; grounded = false; } });
  $('#mobile-run')?.addEventListener('pointerdown', event => { if (document.body.classList.contains('controls-editing')) return; event.currentTarget.setPointerCapture(event.pointerId); keys.add(bindings.run); });
  for (const eventName of ['pointerup', 'pointercancel', 'pointerleave']) $('#mobile-run')?.addEventListener(eventName, () => keys.delete(bindings.run));
  $('#world').addEventListener('contextmenu', event => event.preventDefault());
  window.addEventListener('keydown', event => {
    const rawKey = event.key.toLowerCase(), key = rawKey === ' ' ? 'space' : rawKey;
    if (keys.has(key)) return;
    if (['space', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(key)) event.preventDefault();
    keys.add(key);
    if (key === bindings.pause) location.href = 'pause.html';
    if (key === bindings.interact) interact();
    if (key === bindings.mine) mineNearest();
    if (key === bindings.camera) cycleCamera();
    if (key === bindings.jump && grounded) { verticalSpeed = 7.1; grounded = false; }
    if (key === '1') setWeapon('rifle'); if (key === '2') setWeapon('pistol'); if (key === '3') setWeapon('sniper'); if (key === '4') setWeapon('knife'); if (key === '5') setWeapon('pickaxe');
    if (key === 'r' && state.inventory.ammo > 0) notice('Peluru diambil dari tas secara otomatis.');
  });
  window.addEventListener('keyup', event => keys.delete(event.key.toLowerCase() === ' ' ? 'space' : event.key.toLowerCase()));
  $('#world').addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse') {
      if (event.button === 0) { if (!document.pointerLockElement) { const lock = $('#world').requestPointerLock?.(); lock?.catch?.(() => {}); } shoot(); }
      else { look.down = true; look.x = event.clientX; look.y = event.clientY; $('#world').setPointerCapture(event.pointerId); }
    } else if (event.target === $('#world')) { look.down = true; look.x = event.clientX; look.y = event.clientY; $('#world').setPointerCapture(event.pointerId); }
  });
  $('#world').addEventListener('pointermove', event => {
    if (document.pointerLockElement === $('#world')) {
      yaw -= event.movementX * .0024;
      pitch = Math.max(-.45, Math.min(.72, pitch + event.movementY * .002));
    } else if (look.down && (event.pointerType !== 'mouse' || event.buttons === 2)) {
      yaw -= (event.clientX - look.x) * .0052;
      pitch = Math.max(-.45, Math.min(.72, pitch + (event.clientY - look.y) * .0025));
      look.x = event.clientX; look.y = event.clientY;
    }
  });
  window.addEventListener('pointerup', () => { look.down = false; });

  const stick = $('#joystick'), knob = $('#stick-knob');
  if (stick) {
    stick.addEventListener('pointerdown', event => { if (document.body.classList.contains('controls-editing')) return; stick.setPointerCapture(event.pointerId); joystick.pointer = event.pointerId; moveStick(event); });
    stick.addEventListener('pointermove', event => { if (joystick.pointer === event.pointerId && !document.body.classList.contains('controls-editing')) moveStick(event); });
    const releaseStick = event => { if (joystick.pointer === event.pointerId) { joystick.x = joystick.y = 0; joystick.pointer = null; knob.style.transform = 'translate(0,0)'; } };
    stick.addEventListener('pointerup', releaseStick); stick.addEventListener('pointercancel', releaseStick);
  }
  function moveStick(event) {
    const bounds = stick.getBoundingClientRect(), dx = event.clientX - (bounds.left + bounds.width / 2), dy = event.clientY - (bounds.top + bounds.height / 2);
    const radius = bounds.width * .34, scale = Math.min(1, radius / (Math.hypot(dx, dy) || 1));
    joystick.x = dx * scale / radius; joystick.y = dy * scale / radius;
    knob.style.transform = `translate(${joystick.x * 32}px,${joystick.y * 32}px)`;
  }

  function isBlocked(x, z, ignoreActor = null) {
    if (Math.abs(x) > world.mapHalf - 1.4 || Math.abs(z) > world.mapHalf - 1.4) return true;
    for (const item of world.obstacles) if (Math.hypot(x - item.x, z - item.z) < item.radius + bodyRadius) return true;
    for (const box of world.colliders) {
      if (box.active === false) continue;
      const dx = Math.max(Math.abs(x - box.x) - box.width / 2, 0);
      const dz = Math.max(Math.abs(z - box.z) - box.depth / 2, 0);
      if (dx * dx + dz * dz < bodyRadius * bodyRadius) return true;
    }
    for (const actor of liveThreats()) {
      if (actor === ignoreActor || actor.group.visible === false) continue;
      if (Math.hypot(x - actor.x, z - actor.z) < bodyRadius + (actor.type === 'wolf' ? .48 : .43)) return true;
    }
    for (const npc of world.npcs) if (Math.hypot(x - npc.x, z - npc.z) < bodyRadius + .4) return true;
    for (const remote of world.remotes.values()) if (Math.hypot(x - remote.group.position.x, z - remote.group.position.z) < bodyRadius + .42) return true;
    if (ignoreActor && Math.hypot(x - playerPosition().x, z - playerPosition().z) < bodyRadius + .43) return true;
    return false;
  }
  function moveAxis(x, z) {
    const count = Math.max(1, Math.ceil(Math.hypot(x, z) / .14));
    let movedX = false, movedZ = false;
    for (let i = 0; i < count; i++) {
      const sx = x / count, sz = z / count;
      const tryX = playerPosition().x + sx, currentZ = playerPosition().z;
      const slopeX = Math.abs(world.heightAt(tryX, currentZ) - world.heightAt(playerPosition().x, currentZ));
      if (!isBlocked(tryX, currentZ) && slopeX < .8) { playerPosition().x = tryX; movedX = true; }
      const currentX = playerPosition().x, tryZ = currentZ + sz;
      const slopeZ = Math.abs(world.heightAt(currentX, tryZ) - world.heightAt(currentX, currentZ));
      if (!isBlocked(currentX, tryZ) && slopeZ < .8) { playerPosition().z = tryZ; movedZ = true; }
    }
    return movedX || movedZ;
  }

  function updateAI(dt, now) {
    for (const enemy of [...world.enemies, ...world.animals]) {
      if (!enemy.alive) continue;
      const dx = playerPosition().x - enemy.x, dz = playerPosition().z - enemy.z, dist = Math.hypot(dx, dz);
      if (enemy.healthBar) enemy.healthBar.sprite.visible = enemy.health < enemy.maxHealth && dist < 30;
      const animal = enemy.type === 'wolf', aggroRange = animal ? 19 : 36;
      let vx = 0, vz = 0;
      const retreating = enemy.type === 'raider' && enemy.health < 32 && dist < 14;
      const attackRange = animal ? 1.65 : 1.95;
      if (retreating) {
        vx = -dx / (dist || 1); vz = -dz / (dist || 1);
      } else if (dist < aggroRange) {
        if (dist > attackRange) { vx = dx / (dist || 1); vz = dz / (dist || 1); }
        else {
          vx = dx / (dist || 1) * .18; vz = dz / (dist || 1) * .18;
          if (now >= enemy.attackAt) {
            enemy.attackAt = now + (animal ? 1550 : 1900);
            enemy.attackingUntil = now + 520; enemy.attackHitAt = now + 290; enemy.attackDidHit = false;
          }
          if (enemy.attackingUntil && now >= enemy.attackHitAt && !enemy.attackDidHit) {
            enemy.attackDidHit = true;
            if (dist < attackRange + .35) hurtPlayer(animal ? 9 : 12, enemy.name);
          }
          if (enemy.attackingUntil && now >= enemy.attackingUntil) enemy.attackingUntil = 0;
        }
      } else if (animal) {
        const wanderX = enemy.homeX + Math.sin(now * .00027 + enemy.homeZ) * 5.5;
        const wanderZ = enemy.homeZ + Math.cos(now * .0003 + enemy.homeX) * 5.5;
        const wx = wanderX - enemy.x, wz = wanderZ - enemy.z, wd = Math.hypot(wx, wz);
        if (wd > 1) { vx = wx / wd * .35; vz = wz / wd * .35; }
      }
      const speed = retreating ? enemy.speed * 1.75 : animal ? enemy.speed : enemy.speed * (dist < aggroRange ? 1.45 : .55);
      enemy.moving = Math.hypot(vx, vz) > .08;
      if (enemy.moving) {
        const stepX = vx * speed * dt, stepZ = vz * speed * dt, oldX = enemy.x, oldZ = enemy.z;
        const candidates = [[oldX + stepX, oldZ], [oldX, oldZ + stepZ], [oldX + stepX * .7, oldZ + stepZ * .7]];
        const move = candidates.find(([x, z]) => !isBlocked(x, z, enemy));
        if (move) { enemy.x = move[0]; enemy.z = move[1]; }
        enemy.group.rotation.y = Math.atan2(-vx, -vz);
      }
      enemy.group.position.set(enemy.x, world.heightAt(enemy.x, enemy.z), enemy.z);
      if (enemy.group.userData.limbs) {
        const phase = now * (animal ? .011 : .009);
        enemy.group.userData.limbs.forEach(limb => {
          const wave = enemy.moving ? Math.sin(phase + (limb.side < 0 ? Math.PI : 0)) : 0;
          if (limb.type === 'leg') { limb.upper.rotation.x = wave * .48; limb.lower.rotation.x = Math.max(0, -wave) * .62; }
          else limb.upper.rotation.x = -wave * .3;
        });
        const arm = enemy.group.userData.limbs.find(limb => limb.type === 'arm' && limb.side === 1);
        if (enemy.attackingUntil > now && arm) {
          const phase = 1 - (enemy.attackingUntil - now) / 520;
          arm.upper.rotation.x = -.78 + Math.sin(phase * Math.PI) * 1.35;
          arm.lower.rotation.x = .62;
          enemy.group.rotation.x = Math.sin(phase * Math.PI) * -.1;
        } else enemy.group.rotation.x = THREE.MathUtils.damp(enemy.group.rotation.x, 0, 8, dt);
        enemy.group.userData.head.rotation.x = enemy.hitAt && now - enemy.hitAt < 260 ? -.22 : THREE.MathUtils.damp(enemy.group.userData.head.rotation.x, 0, 8, dt);
      } else if (enemy.attackingUntil > now) {
        const phase = 1 - (enemy.attackingUntil - now) / 520;
        enemy.group.userData.head.rotation.x = -.15 - Math.sin(phase * Math.PI) * .72;
        enemy.group.position.y += Math.sin(phase * Math.PI) * .24;
      } else {
        enemy.group.userData.head.rotation.x = THREE.MathUtils.damp(enemy.group.userData.head.rotation.x, 0, 8, dt);
      }
    }
  }

  function renderMinimap() {
    const map = $('#minimap'), context = map?.getContext('2d'); if (!context) return;
    const width = map.width, height = map.height, scaleX = width / (world.mapHalf * 2), scaleZ = height / (world.mapHalf * 2);
    const point = (x, z) => [(x + world.mapHalf) * scaleX, (z + world.mapHalf) * scaleZ];
    context.clearRect(0, 0, width, height); context.fillStyle = '#455f43'; context.fillRect(0, 0, width, height);
    context.strokeStyle = '#73885d'; context.lineWidth = 1;
    for (let grid = 1; grid < 4; grid++) { context.beginPath(); context.moveTo(grid * width / 4, 0); context.lineTo(grid * width / 4, height); context.moveTo(0, grid * height / 4); context.lineTo(width, grid * height / 4); context.stroke(); }
    context.beginPath(); world.stream.forEach((spot, index) => { const [x, y] = point(spot.x, spot.z); if (!index) context.moveTo(x, y); else context.lineTo(x, y); });
    context.strokeStyle = '#65b4c1'; context.lineWidth = 5.5; context.stroke();
    for (const building of world.buildings) {
      const [x, y] = point(building.group.position.x, building.group.position.z);
      context.fillStyle = '#d4bd86'; context.fillRect(x - 3, y - 2.5, 6, 5);
    }
    for (const threat of liveThreats()) {
      const [x, y] = point(threat.x, threat.z); context.beginPath(); context.fillStyle = threat.type === 'wolf' ? '#fd8d53' : '#f25348'; context.arc(x, y, 3, 0, Math.PI * 2); context.fill();
    }
    for (const [username, remote] of world.remotes) { const [x, y] = point(remote.group.position.x, remote.group.position.z); if(x>=0&&x<=width&&y>=0&&y<=height){context.beginPath();context.fillStyle='#e6d356';context.arc(x,y,3.2,0,Math.PI*2);context.fill();} }
    const player = playerPosition(), [px, py] = point(player.x, player.z);
    context.save(); context.translate(px, py); context.rotate(yaw);
    context.beginPath(); context.moveTo(0, -8); context.lineTo(-5.5, 6); context.lineTo(5.5, 6); context.closePath();
    context.fillStyle = '#f6c635'; context.strokeStyle = '#171a14'; context.lineWidth = 1.4; context.fill(); context.stroke(); context.restore();
    context.strokeStyle = '#f2e8c8'; context.lineWidth = 2; context.strokeRect(1, 1, width - 2, height - 2);
    const coords = $('#map-coords'); if (coords) coords.textContent = `${Math.round(player.x)}, ${Math.round(player.z)}`;
  }

  try {
    network = connectSocket();
    network.onopen = () => {
      networkReady = true; const room = sessionStorage.getItem('brdanz-room-code'); network.send(JSON.stringify(room ? { type: 'join_room', code: room } : { type:'join_global' }));
      const status = $('#net-status'); if (status) status.textContent = 'Mencari survivor...';
    };
    network.onclose = () => { networkReady = false; const status = $('#net-status'); if (status) status.textContent = 'Offline'; };
    network.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.type === 'welcome') { state.player.name = message.username; renderStats(); }
      if (message.type === 'room_joined') {
        for (const player of message.room.players) if (player.username !== state.player.name) { const remote=world.addRemote(player.username); remote.target.set(player.x,world.heightAt(player.x,player.z),player.z); remote.group.position.copy(remote.target); remote.yaw=player.yaw||0; }
        const status=$('#net-status'); if(status)status.textContent=`GLOBAL · ${message.room.players.length}/${message.room.max}`;
      }
      if (message.type === 'state' && message.state.username !== state.player.name) {
        const remote = world.addRemote(message.state.username); remote.target.set(message.state.x, world.heightAt(message.state.x, message.state.z), message.state.z); remote.yaw = message.state.yaw; remote.moving=message.state.moving;
      }
      if (message.type === 'player_joined' && message.username !== state.player.name) { const remote=world.addRemote(message.username); if(message.state){remote.target.set(message.state.x,world.heightAt(message.state.x,message.state.z),message.state.z);remote.group.position.copy(remote.target);} }
      if (message.type === 'player_attacked') { state.player.hp=Math.max(0,message.hp); world.playAction('hurt'); const flash=$('#damage-flash');flash?.classList.add('active');setTimeout(()=>flash?.classList.remove('active'),180); if(state.player.hp===0){state.world.position={x:0,y:0,z:0};notice(`Dikalahkan ${message.username}. Kamu bangkit kembali di kamp.`);state.player.hp=100;} else notice(`${message.username} mengenai kamu · HP ${state.player.hp}`); persist(); }
      if (message.type === 'player_hit') notice(`Tembakan mengenai ${message.target} · ${message.hp} HP tersisa.`);
      if (message.type === 'player_killed') { state.player.kills++; state.player.coins+=80; notice(`Pemain ${message.target} tumbang · +80 koin.`); persist(); }
      if (message.type === 'player_killed_by') notice(`${message.username} menjatuhkanmu. Kamu muncul kembali di kamp.`);
      if (message.type === 'player_respawn') { state.player.hp=message.hp; persist(); }
      if (message.type === 'player_left') world.removeRemote(message.username);
    };
  } catch { const status = $('#net-status'); if (status) status.textContent = 'Offline'; }

  const frame = now => {
    const dt = Math.min((now - previousTime) / 1000, .05); previousTime = now;
    survivalTimer += dt; attackTimer += dt; damageCooldown = Math.max(0, damageCooldown - dt); fireTimer = Math.max(0, fireTimer - dt); movementClock += dt; environmentTimer += dt;
    state.world.timeOfDay = (state.world.timeOfDay + dt * .04) % 24;
    if (state.world.timeOfDay < dt * .04) state.world.day++;
    if (environmentTimer > .2) { environmentTimer = 0; world.setTimeOfDay(state.world.timeOfDay); const hour = Math.floor(state.world.timeOfDay), minute = Math.floor((state.world.timeOfDay % 1) * 60); $('#day-clock').textContent = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`; $('#day-count').textContent = state.world.day; }
    weatherTimer += dt;
    if (weatherTimer > 145) { weatherTimer = 0; const cycle = ['clear', 'cloudy', 'rain'], next = cycle[(cycle.indexOf(state.world.weather) + 1) % cycle.length]; state.world.weather = next; world.setWeather(next); if (weatherLabel) { weatherLabel.textContent = weatherNames[next]; weatherLabel.dataset.weather = next; } persist(); notice(`Cuaca berubah: ${weatherNames[next].toLowerCase()}.`, 3200); }
    if (survivalTimer >= 30) {
      survivalTimer -= 30; state.player.hunger = Math.max(0, state.player.hunger - 1); state.player.thirst = Math.max(0, state.player.thirst - 2); persist();
    }
    if ((state.player.hunger === 0 || state.player.thirst === 0) && attackTimer >= 5) {
      attackTimer = 0; state.player.hp = Math.max(0, state.player.hp - 2); persist();
      if (state.player.hp <= 0) { saveGame(state); location.href = 'gameover.html'; return; }
    }
    const forward = (bound('forward') || keys.has('arrowup') ? 1 : 0) - (bound('backward') || keys.has('arrowdown') ? 1 : 0) - joystick.y;
    const strafe = (bound('right') || keys.has('arrowright') ? 1 : 0) - (bound('left') || keys.has('arrowleft') ? 1 : 0) + joystick.x;
    const length = Math.hypot(forward, strafe), normalizer = length > 1 ? 1 / length : 1;
    const moving = length > .08, inWater = Math.abs(playerPosition().x - (24 + Math.sin(playerPosition().z * .027) * 14 + Math.sin(playerPosition().z * .063) * 3)) < 2.95;
    const run = (bound('run') || keys.has('shiftleft')) && stamina > 1 && moving && !inWater;
    const speed = inWater ? (moving ? 2.65 : 0) : run ? runningSpeed : walkingSpeed;
    let actualSpeed = 0;
    if (moving) {
      const f = forward * normalizer, s = strafe * normalizer;
      const dx = (-Math.sin(yaw) * f + Math.cos(yaw) * s) * speed * dt;
      const dz = (-Math.cos(yaw) * f - Math.sin(yaw) * s) * speed * dt;
      const oldX = playerPosition().x, oldZ = playerPosition().z;
      moveAxis(dx, dz);
      const movedX = playerPosition().x - oldX, movedZ = playerPosition().z - oldZ;
      actualSpeed = Math.hypot(movedX, movedZ) / Math.max(dt, .001);
      if (actualSpeed > .08) world.hero.rotation.y = THREE.MathUtils.damp(world.hero.rotation.y, Math.atan2(-movedX, -movedZ), 11, dt);
    }
    else world.hero.rotation.y = THREE.MathUtils.damp(world.hero.rotation.y, yaw, 10, dt);
    stamina = Math.max(0, Math.min(100, stamina + (run && actualSpeed > .12 ? -23 : 14) * dt)); state.player.stamina = stamina;
    if (inWater) {
      verticalSpeed = 0; grounded = false;
      const waterline = world.waterLevelAt(playerPosition().x, playerPosition().z) - .82 + Math.sin(now * .0032) * .045;
      const swimY = THREE.MathUtils.damp(world.hero.position.y, waterline, 5.5, dt);
      world.hero.position.set(playerPosition().x, swimY, playerPosition().z);
    } else {
      verticalSpeed -= 18 * dt;
      const floor = world.heightAt(playerPosition().x, playerPosition().z);
      const newY = world.sleepLift > .01 ? floor + world.sleepLift : Math.max(floor, world.hero.position.y + verticalSpeed * dt);
      world.hero.position.set(playerPosition().x, newY, playerPosition().z);
      if (newY <= floor + .001) { verticalSpeed = 0; grounded = true; } else if (world.sleepLift <= .01) grounded = false; else { verticalSpeed = 0; grounded = false; }
    }
    state.world.position.y = world.hero.position.y; state.world.yaw = yaw;

    const focus = new THREE.Vector3(world.hero.position.x, world.hero.position.y + 1.47, world.hero.position.z);
    const viewDirection = new THREE.Vector3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch)).normalize();
    if (cameraMode === 'first') {
      const eye = new THREE.Vector3(world.hero.position.x, world.hero.position.y + 1.67, world.hero.position.z);
      world.camera.position.copy(eye); world.camera.lookAt(eye.clone().addScaledVector(viewDirection, 12));
    } else {
      const shoulder = cameraMode === 'shoulder';
      const distanceBack = (shoulder ? 3.9 : 7.4) + Math.max(0, pitch) * (shoulder ? 1.4 : 3.8);
      const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
      const anchor = focus.clone().addScaledVector(right, shoulder ? .48 : 0);
      const desired = new THREE.Vector3(anchor.x + Math.sin(yaw) * distanceBack, anchor.y + Math.tan(pitch) * distanceBack, anchor.z + Math.cos(yaw) * distanceBack);
      const rayDirection = desired.clone().sub(anchor).normalize(); world.raycaster.set(anchor, rayDirection); world.raycaster.far = distanceBack;
      const cameraHits = world.raycaster.intersectObjects(world.cameraBlockers, false);
      if (cameraHits.length) desired.copy(anchor).addScaledVector(rayDirection, Math.max(1.1, cameraHits[0].distance - .48));
      desired.y = Math.max(desired.y, world.heightAt(desired.x, desired.z) + .8);
      world.camera.position.x = THREE.MathUtils.damp(world.camera.position.x, desired.x, 13, dt);
      world.camera.position.y = THREE.MathUtils.damp(world.camera.position.y, desired.y, 13, dt);
      world.camera.position.z = THREE.MathUtils.damp(world.camera.position.z, desired.z, 13, dt);
      world.camera.position.y = Math.max(world.camera.position.y, world.heightAt(world.camera.position.x, world.camera.position.z) + .8);
      world.camera.lookAt(anchor);
    }
    world.setMoving(actualSpeed > .12 && !inWater, actualSpeed / walkingSpeed);
    world.setSwimming(inWater, Math.max(.55, actualSpeed / walkingSpeed));
    for (const remote of world.remotes.values()) {
      remote.group.position.lerp(remote.target, Math.min(1, dt * 10)); remote.group.rotation.y = remote.yaw;
    }
    updateAI(dt, now);
    const prompt = nearestAction(), promptEl = $('#interact-prompt'), promptText = $('#interact-label');
    if (promptEl && promptText) { promptEl.hidden = !prompt; if (prompt) { promptText.textContent = prompt.label; const key = promptEl.querySelector('kbd'); if (key) key.textContent = keyLabel(bindings[prompt.type === 'mine' ? 'mine' : 'interact']); } }
    if (now - mapTimer > 90) { mapTimer = now; renderMinimap(); }
    if (networkReady && Math.floor(now / 100) % 4 === 0) network.send(JSON.stringify({ type: 'state', position: state.world.position, yaw, moving }));
    if (Math.floor(now / 500) % 2 === 0 && Math.floor(now / 500) !== Math.floor((now - dt * 1000) / 500)) renderStats();
    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
  const saveTimer = setInterval(() => { state.world.played++; saveGame(state); }, 5000);
  window.addEventListener('beforeunload', () => { clearInterval(saveTimer); clearTimeout(noticeTimer); saveGame(state); network?.close(); }, { once: true });
}

if (page === 'rank') {
  $$('.rank-name').forEach((element, index) => element.textContent = [state.player.name, 'Raza', 'Bintang'][index] || 'Pemain');
  $$('.rank-score').forEach((element, index) => element.textContent = [state.player.xp + 1250, 1180, 1100][index]);
}

if (page === 'house') {
  const noticeEl = $('#house-notice'), houseInfo = { guardian:{name:'Rumah Penjaga',x:0,z:-20}, forest:{name:'Kabin Hutan',x:-37,z:18}, hill:{name:'Rumah Bukit',x:68,z:50} };
  const renderHouses = () => {
    $$('[data-house-card]').forEach(card => {
      const id = card.dataset.houseCard, house = state.world.houses[id], owned = Boolean(house?.owned), status = card.querySelector('[data-house-status]');
      if (status) status.textContent = owned ? `Dimiliki · Level ${house.level}` : 'Belum dimiliki';
      const buy = card.querySelector('[data-house-buy]'), upgrade = card.querySelector('[data-house-upgrade]');
      if (buy) buy.hidden = owned;
      if (upgrade) { upgrade.hidden = !owned; upgrade.disabled = owned && house.level >= 5; upgrade.textContent = house.level >= 5 ? 'Level maksimum' : `Tingkatkan · ${((house.level || 1) * 850).toLocaleString('id-ID')} koin`; }
    });
  };
  renderHouses();
  $$('[data-house-buy]').forEach(button => button.addEventListener('click', () => {
    const id = button.dataset.houseBuy, cost = Number(button.dataset.cost);
    if (state.player.coins < cost) { noticeEl.textContent = `Koin belum cukup. Butuh ${cost.toLocaleString('id-ID')} koin.`; return; }
    state.player.coins -= cost; state.world.houses[id] = { owned:true, level:1 }; persist(); noticeEl.textContent = `${houseInfo[id].name} dibeli. Bentuk rumah diperbarui.`; renderHouses(); setTimeout(() => location.reload(), 650);
  }));
  $$('[data-house-upgrade]').forEach(button => button.addEventListener('click', () => {
    const id = button.dataset.houseUpgrade, house = state.world.houses[id]; if (!house?.owned || house.level >= 5) return;
    const cost = house.level * 850; if (state.player.coins < cost) { noticeEl.textContent = `Koin belum cukup. Butuh ${cost.toLocaleString('id-ID')} koin.`; return; }
    state.player.coins -= cost; house.level++; persist(); noticeEl.textContent = `${houseInfo[id].name} sekarang level ${house.level}.`; renderHouses(); setTimeout(() => location.reload(), 650);
  }));
  $('#sleep-at-home')?.addEventListener('click', () => {
    state.world.timeOfDay = 7; state.world.day++; state.player.hp = Math.min(100, state.player.hp + 35); state.player.hunger = Math.max(0, state.player.hunger - 5); state.player.thirst = Math.max(0, state.player.thirst - 7); persist();
    $('#world')?.__world?.playAction('sleep'); $('#world')?.__world?.setTimeOfDay(state.world.timeOfDay);
    if (noticeEl) noticeEl.textContent = 'Kamu tidur dan bangun pada pukul 07:00. HP pulih.';
  });
}

if (page === 'spin') {
  let spinning = false;
  $('#spin-button')?.addEventListener('click', () => {
    if (spinning) return;
    const cost = 150, result = $('#spin-result'), wheel = $('#spin-wheel');
    if (state.player.coins < cost) { result.textContent = 'Koin kurang. Kumpulkan loot atau selesaikan misi dulu.'; return; }
    spinning = true; state.player.coins -= cost; persist();
    const options = [
      { label:'+350 koin', grant: s => { s.player.coins += 350; } },
      { label:'+700 koin', grant: s => { s.player.coins += 700; } },
      { label:'+4 permata', grant: s => { s.player.gems += 4; } },
      { label:'+8 kayu dan +6 batu', grant: s => { s.inventory.wood += 8; s.inventory.stone += 6; } },
      { label:'2 medkit', grant: s => { s.inventory.medkit += 2; } },
      { label:'5 peluru sniper', grant: s => { s.inventory.sniperAmmo += 5; } },
      { label:'Skin Nomad', grant: s => { if (!s.unlockedSkins.includes('Nomad')) { s.unlockedSkins.push('Nomad'); s.skin = 'Nomad'; } else s.player.coins += 500; } },
      { label:'Ransum suplai', grant: s => { s.inventory.food += 3; s.inventory.water += 3; } }
    ];
    const selected = options[Math.floor(Math.random() * options.length)], index = options.indexOf(selected), angle = 360 * 5 + index * 45 + 22.5;
    wheel.style.transform = `rotate(${angle}deg)`;
    setTimeout(() => { selected.grant(state); persist(); result.textContent = `Kamu mendapat ${selected.label}.`; spinning = false; }, 3250);
  });
}
