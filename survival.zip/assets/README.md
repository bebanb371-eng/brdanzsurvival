# Assets

World surface materials are generated in JavaScript from world-space 3D shader noise in `src/materials.js`. The old texture atlas crops are not loaded by the game at runtime. Character, foliage, buildings, and props are meshes assembled by Three.js.

`video/brdanz-loading.mp4` is the supplied loading-screen clip.
