import fs from 'node:fs';
import zlib from 'node:zlib';
const source='C:/Users/toshiba/Pictures/e21941ac-34f7-4c62-b269-53a4450b6173.png';
const file=fs.readFileSync(source),sig=file.subarray(0,8);let off=8,w,h,depth,color,compressed=[];
while(off<file.length){const n=file.readUInt32BE(off),type=file.toString('ascii',off+4,off+8),data=file.subarray(off+8,off+8+n);if(type==='IHDR'){w=data.readUInt32BE(0);h=data.readUInt32BE(4);depth=data[8];color=data[9]}if(type==='IDAT')compressed.push(data);off+=12+n}
if(depth!==8||color!==2)throw new Error(`Unsupported PNG ${depth}/${color}`);
const bpp=3,stride=w*bpp,raw=zlib.inflateSync(Buffer.concat(compressed)),pixels=Buffer.alloc(h*stride);let src=0;
function paeth(a,b,c){const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c}
for(let y=0;y<h;y++){const f=raw[src++],row=y*stride;for(let x=0;x<stride;x++){const v=raw[src++],a=x>=bpp?pixels[row+x-bpp]:0,b=y?pixels[row-stride+x]:0,c=y&&x>=bpp?pixels[row-stride+x-bpp]:0;pixels[row+x]=(v+(f===0?0:f===1?a:f===2?b:f===3?Math.floor((a+b)/2):paeth(a,b,c)))&255}}
const table=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0});
function crc(buf){let c=0xffffffff;for(const b of buf)c=table[(c^b)&255]^(c>>>8);return(c^0xffffffff)>>>0}
function chunk(name,data){const t=Buffer.from(name),out=Buffer.alloc(12+data.length);out.writeUInt32BE(data.length,0);t.copy(out,4);data.copy(out,8);out.writeUInt32BE(crc(Buffer.concat([t,data])),8+data.length);return out}
function encode(width,height,rgb){const hdr=Buffer.alloc(13);hdr.writeUInt32BE(width,0);hdr.writeUInt32BE(height,4);hdr[8]=8;hdr[9]=2;const scan=Buffer.alloc(height*(1+width*3));for(let y=0;y<height;y++)rgb.copy(scan,y*(1+width*3)+1,y*width*3,(y+1)*width*3);return Buffer.concat([sig,chunk('IHDR',hdr),chunk('IDAT',zlib.deflateSync(scan)),chunk('IEND',Buffer.alloc(0))])}
const crops=[['grass',274,31,136,134],['soil',1,31,134,134],['gravel',138,174,135,137],['rock',424,176,140,137],['wood-planks',716,31,144,135],['wood-endgrain',862,175,143,138],['rusty-metal',1022,31,100,134],['brick',1336,31,115,134],['concrete',1456,31,103,134],['leaves',4,354,99,95],['camo',811,354,98,113]];
fs.mkdirSync('assets/textures',{recursive:true});
for(const[name,x,y,cw,ch]of crops){const rgb=Buffer.alloc(cw*ch*3);for(let row=0;row<ch;row++){const a=((y+row)*w+x)*3;pixels.copy(rgb,row*cw*3,a,a+cw*3)}const dest=`assets/textures/${name}.png`;fs.writeFileSync(dest,encode(cw,ch,rgb));console.log(dest,cw,ch)}
