import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const replacements = new Map([
  ['🧑', 'person'], ['🪵', 'wood'], ['🪨', 'rock'], ['🔩', 'metal'], ['🔥', 'fire'], ['🧰', 'medkit'], ['🔸', 'ammo'], ['🎁', 'gift'], ['🪙', 'coin'], ['💧', 'waterdrop'], ['🥫', 'food'], ['🔹', 'ammo'], ['🎯', 'sniper'], ['🪖', 'helmet'], ['🔒', 'lock'], ['🥷', 'shadow'], ['🌲', 'forest'], ['🛒', 'shop'], ['🎒', 'inventory'], ['❤', 'heart'], ['🍗', 'food'], ['⚡', 'stamina'], ['🍖', 'food'], ['🧴', 'waterdrop'], ['🔫', 'rifle'], ['🗡', 'knife'], ['▶', 'play'], ['⚙', 'settings'], ['💎', 'gem'], ['☀', 'sun'], ['🔵', 'location'], ['🟡', 'location'], ['🔴', 'zone'], ['🟢', 'shield'], ['🛡', 'shield'], ['🧭', 'compass'], ['🏅', 'rank']
]);
const icon = id => `<svg class="icon icon-${id}" aria-hidden="true" focusable="false"><use href="/assets/icons.svg#${id}"></use></svg>`;
for (const name of fs.readdirSync(root).filter(file => file.endsWith('.html'))) {
  const file = path.join(root, name);
  const before = fs.readFileSync(file, 'utf8');
  const after = before.replace(/\p{Extended_Pictographic}(?:\uFE0F)?(?:\p{Emoji_Modifier})?/gu, glyph => {
    const normalized = glyph.replace(/\uFE0F/g, '').replace(/\p{Emoji_Modifier}/gu, '');
    if (normalized === '©') return glyph;
    const id = replacements.get(normalized);
    if (!id) { console.warn(`No SVG icon mapping for ${glyph} in ${name}`); return glyph; }
    return icon(id);
  });
  if (after !== before) fs.writeFileSync(file, after);
}
